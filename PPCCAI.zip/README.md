# PPCCAIProject

Let start working